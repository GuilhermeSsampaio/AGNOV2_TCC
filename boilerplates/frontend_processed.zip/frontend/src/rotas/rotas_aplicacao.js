import { Route, BrowserRouter, Routes } from "react-router-dom";
import RotasUsuarioLogado from "./rotas-usuario-logado";
import LogarUsuario from "../paginas/usuario/logar-usuario";
import CadastrarUsuario from "../paginas/usuario/cadastrar-usuario";
import PaginaInicial from "../paginas/usuario/pagina-inicial";
import RecuperarAcesso from "../paginas/usuario/recuperar-acesso";

export default function Rotas() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<LogarUsuario />} path="/" />
        <Route element={<CadastrarUsuario />} path="criar-usuario" />
        <Route element={<RecuperarAcesso />} path="recuperar-acesso" />

        <Route element={<RotasUsuarioLogado />}>
          <Route element={<PaginaInicial />} path="pagina-inicial" />
          <Route element={<CadastrarUsuario />} path="atualizar-usuario" />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
