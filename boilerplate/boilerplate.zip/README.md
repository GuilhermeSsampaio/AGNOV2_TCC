# Boilerplate React App

Base para novos projetos com layout e estilo padronizados.