# from agno.models.ollama import Ollama

# # --- O SEU PONTO CENTRAL PARA CONFIGURAR MODELOS LOCAIS ---

# # Define o ID do modelo que descarregou.
# # Pode alterar para "phi-3:3.8b-mini-128k-instruct-q4_K_M" ou outro no futuro.
# # LOCAL_MODEL_ID = "deepseek-coder:6.7b-instruct-q4_K_M"
# # LOCAL_MODEL_ID = "llama3.2:3b"
# LOCAL_MODEL_ID = "llama3.1:8b"

# # LOCAL_MODEL_ID = "gemma:2b-instruct"
# # LOCAL_MODEL_ID = "qwen2.5-coder:7b"



# # Cria a instância do modelo que será usada pelos seus agentes.
# # O Agno irá comunicar com o seu Ollama local.
# local_model = Ollama(id=LOCAL_MODEL_ID)
# print(f"--- Configuração de Modelo Local: A usar '{LOCAL_MODEL_ID}' via Ollama. ---")
