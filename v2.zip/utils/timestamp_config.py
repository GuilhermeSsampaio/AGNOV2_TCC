from datetime import datetime

project_timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
project_path = f"projects/project_{project_timestamp}"